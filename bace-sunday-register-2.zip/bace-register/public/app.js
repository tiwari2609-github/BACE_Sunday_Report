(function(){
'use strict';
var $=function(s){return document.querySelector(s);};
var pad=function(n){return String(n).padStart(2,'0');};
var esc=function(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});};
function ymd(d){return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());}
function parseYmd(s){var p=s.split('-').map(Number);return new Date(p[0],p[1]-1,p[2]);}
function addDays(s,n){var d=parseYmd(s);d.setDate(d.getDate()+n);return ymd(d);}
function nextSunday(){var d=new Date();d.setDate(d.getDate()+((7-d.getDay())%7));return ymd(d);}
function toMin(t){if(!t)return null;var p=t.split(':').map(Number);return p[0]*60+p[1];}
function fmt12(t){var p=t.split(':').map(Number);return ((p[0]+11)%12+1)+':'+pad(p[1])+(p[0]>=12?' pm':' am');}
function minsText(n){n=Math.abs(n);if(n<60)return n+' min';var h=Math.floor(n/60),m=n%60;return h+' h'+(m?' '+m+' min':'');}
function longDate(s){return parseYmd(s).toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long',year:'numeric'});}
function shortDate(s){return parseYmd(s).toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'});}

/* ---------- schedule ---------- */
var LEVELS=[2,3,4,5,6,7,8,9,10,11];
function buildSessions(test){
  var s=[
    {id:'mridanga',kind:'class',grp:'Cultural class',name:'Mridanga Class',start:'08:00',end:'09:00',counts:'offline',role:'Teacher',topic:'Topic or taal practised'},
    {id:'breakfast',kind:'food',grp:'Breakfast',name:'Breakfast Prasadam',start:'09:00',end:'09:30'},
    {id:'gs',kind:'class',grp:'Sabhas',name:'Gauranga Sabha',short:'GS',start:'09:30',end:'10:30',counts:'offline',role:'Speaker',topic:'Topic'},
    {id:'ns',kind:'class',grp:'Sabhas',name:'Nityananda Sabha',short:'NS',start:'09:30',end:'10:30',counts:'offline',role:'Speaker',topic:'Topic'}
  ];
  LEVELS.forEach(function(n){s.push({id:'L'+n,kind:'class',level:true,grp:'Level classes',name:'Level '+n,short:'L'+n,start:'10:30',end:'12:30',counts:'both',role:'Speaker',topic:'Topic or chapter'});});
  if(test)s.push({id:'common',kind:'class',grp:'Common class',name:'Common Class',start:'12:30',end:'13:30',counts:'both',role:'Speaker',topic:'Test and presentation details'});
  s.push({id:'lunch',kind:'food',grp:'Prasadam',name:'Prasadam',start:test?'13:30':'12:30',end:'14:30'});
  s.push({id:'slm',kind:'meeting',grp:'Meeting',name:'Servant Leader Meeting',start:'14:30',end:'15:00'});
  s.push({id:'rv',kind:'class',grp:'Raja Vidya',name:'Raja Vidya Class',short:'Raja Vidya',start:'15:00',end:'18:00',counts:'offline',role:'Speaker',topic:'Topic',place:'Temple'});
  return s;
}

/* ---------- state and server ---------- */
var entries=new Map();
var state={tab:'day',date:nextSunday(),sid:'overview',sync:'loading',readOnly:false,railOpen:false};
var me=null,events=null,pollTimer=null,fetchTimer=null;
var pending=new Map(),inflight=0,busy=new Set();

function api(method,url,body){
  var opts={method:method,credentials:'same-origin',headers:{'X-Requested-With':'bace'}};
  if(body!==undefined){opts.headers['Content-Type']='application/json';opts.body=JSON.stringify(body);}
  return fetch(url,opts).then(function(r){
    return r.json().catch(function(){return {};}).then(function(j){
      if(r.status===401&&url!=='/api/login'){showLogin();}
      if(!r.ok){var e=new Error(j.error||'Something went wrong');e.status=r.status;throw e;}
      return j;
    });
  });
}
function key(d,s){return d+'__'+s;}
function getEntry(d,s){return entries.get(key(d,s))||{};}
function isTest(d){return !!getEntry(d,'day').testDay;}
function sessionsFor(d){return buildSessions(isTest(d));}
function sessionOn(d,sid){var f=sessionsFor(d).find(function(x){return x.id===sid;});return f||buildSessions(true).find(function(x){return x.id===sid;});}
function getSessions(){return sessionsFor(state.date);}

function setEntry(d,sid,patch){
  if(state.readOnly)return;
  var k=key(d,sid);
  var next=Object.assign({},entries.get(k)||{},patch,{date:d,sid:sid,updatedAt:Date.now(),byName:me?me.fullName:''});
  Object.keys(next).forEach(function(f){if(next[f]===''||next[f]==null)delete next[f];});
  entries.set(k,next);
  queueSave(k);
}
function queueSave(k){
  clearTimeout(pending.get(k));
  setSync('saving');
  pending.set(k,setTimeout(function(){flush(k);},500));
}
function settleSync(){if(pending.size===0&&inflight===0&&!state.readOnly)setSync('saved');}
function flush(k){
  pending.delete(k);
  if(busy.has(k)){pending.set(k,setTimeout(function(){flush(k);},300));return;}
  var data=Object.assign({},entries.get(k));
  delete data.byName;delete data.updatedAt;
  busy.add(k);inflight++;
  api('PUT','/api/entries/'+encodeURIComponent(k),data).then(function(){
    busy.delete(k);inflight--;settleSync();
  }).catch(function(e){
    busy.delete(k);inflight--;
    if(e.status===403){state.readOnly=true;setSync('readonly');renderBanner();return;}
    if(e.status===401)return;
    setSync('error');
    pending.set(k,setTimeout(function(){flush(k);},8000));
  });
}
function fetchAll(){
  return api('GET','/api/entries').then(function(all){
    Object.keys(all).forEach(function(k){
      if(pending.has(k)||busy.has(k))return;
      entries.set(k,all[k]);
    });
    onDataChanged();
  }).catch(function(){});
}
function scheduleFetch(){clearTimeout(fetchTimer);fetchTimer=setTimeout(fetchAll,250);}
function connectEvents(){
  if(events)events.close();
  try{
    events=new EventSource('/api/events');
    events.onmessage=function(ev){
      try{var m=JSON.parse(ev.data);if(m.type==='people'&&state.tab==='account'){return;}}catch(e){}
      scheduleFetch();
    };
  }catch(e){events=null;}
  clearInterval(pollTimer);pollTimer=setInterval(fetchAll,60000);
}
function setSync(s){
  state.sync=s;
  var el=$('#sync');if(!el)return;
  var map={loading:'Connecting',saving:'Saving',saved:'Saved. Everyone sees updates live',error:'Not saved yet. Retrying',readonly:'Live view. Updates appear as coordinators enter them'};
  el.className='sync '+(s==='saved'||s==='readonly'?'saved':s==='error'?'error':s==='saving'?'saving':'');
  el.innerHTML='<i></i><span>'+esc(map[s]||'')+'</span>';
}
function renderBanner(){
  var b=$('#banner');if(!b)return;
  if(state.readOnly){b.hidden=false;b.textContent='You are watching the live register. Only coordinators can enter or change reports.';}
  else b.hidden=true;
}

/* ---------- timing ---------- */
function timing(e,s){
  if(e.held===false)return {state:'off'};
  var as=toMin(e.actualStart),ae=toMin(e.actualEnd),ss=toMin(s.start),se=toMin(s.end);
  if(as==null)return {state:'pending'};
  var late=as-ss;
  return {state:late>0?'late':late<0?'early':'ok',late:late,over:ae==null?null:ae-se,dur:ae==null?null:ae-as,bad:ae!=null&&ae<as};
}
function chipHtml(t){
  if(t.state==='off')return '<span class="chip off">Not held</span>';
  if(t.state==='pending')return '<span class="chip pending">Not started</span>';
  if(t.state==='ok')return '<span class="chip ok">On time</span>';
  if(t.state==='early')return '<span class="chip early">'+minsText(t.late)+' early</span>';
  return '<span class="chip late">'+minsText(t.late)+' late</span>';
}
function shortMark(t){
  if(t.state==='off')return 'off';if(t.state==='pending')return '';
  if(t.state==='ok')return '0';return (t.late>0?'+':'−')+Math.abs(t.late);
}
function chipText(t){return t.state==='late'?minsText(t.late)+' late':t.state==='early'?minsText(t.late)+' early':t.state==='ok'?'On time':t.state==='off'?'Not held':'Not started';}
function timingHtml(e,s){
  var t=timing(e,s);
  if(t.state==='off')return '<span class="chip off">Not held</span>';
  if(t.state==='pending')return '<span class="chip pending">Not started</span><span class="sm">Enter the actual start time to record any delay.</span>';
  var out=chipHtml(t);
  out+='<span class="sm">Scheduled '+fmt12(s.start)+', started '+fmt12(e.actualStart)+'</span>';
  if(t.bad)out+='<span class="chip off">End time is before start time</span>';
  else if(t.over!=null){
    out+='<span class="sm">Ended '+fmt12(e.actualEnd)+(t.over>0?', '+minsText(t.over)+' over':t.over<0?', '+minsText(t.over)+' early':', right on schedule')+'</span>';
    out+='<span class="sm">Ran for '+minsText(t.dur)+'</span>';
  }
  return out;
}

/* ---------- name suggestions ---------- */
function refreshLists(){
  var sp=new Set(),sv=new Set();
  entries.forEach(function(e){
    if(e.speaker)sp.add(e.speaker);if(e.facilitator)sp.add(e.facilitator);
    (e.servers||[]).forEach(function(n){sv.add(n);});
  });
  var f=function(set){return Array.from(set).sort().map(function(n){return '<option value="'+esc(n)+'">';}).join('');};
  $('#dl-speakers').innerHTML=f(sp);$('#dl-servers').innerHTML=f(sv);
}

/* ---------- bar ---------- */
function cycleInfo(d){
  if(isTest(d))return 'Common class runs 12:30 to 1:30 pm. Prasadam starts at 1:30 pm.';
  var dates=Array.from(new Set(Array.from(entries.values()).map(function(e){return e.date;}).filter(Boolean))).filter(function(x){return x<d;}).sort().reverse();
  var n=0,found=false;
  for(var i=0;i<dates.length;i++){if(isTest(dates[i])){found=true;break;}n++;}
  var base='No common class. Prasadam starts at 12:30 pm.';
  if(found&&n>=3)return base+' <b>'+n+' Sundays since the last test day, so a test may be due.</b>';
  return base;
}
function renderBar(){
  $('#date').value=state.date;
  var dow=parseYmd(state.date).getDay();
  $('#dayname').textContent=longDate(state.date)+(dow!==0?' (not a Sunday)':'');
  $('#testDay').checked=isTest(state.date);
  $('#testDay').disabled=state.readOnly;
  $('#hint').innerHTML=cycleInfo(state.date);
  $('#bar').hidden=state.tab!=='day';
}
function applyReadOnly(){
  if(!state.readOnly)return;
  document.querySelectorAll('#pane input:not([readonly]),#pane textarea:not([readonly]),#pane [data-now],#pane [data-rm]').forEach(function(el){el.disabled=true;});
}
function attr(e){
  if(!e||!e.updatedAt||!e.byName)return '';
  var at=new Date(e.updatedAt);
  return '<p class="note">Last updated by '+esc(e.byName)+' at '+esc(at.toLocaleTimeString('en-IN',{hour:'numeric',minute:'2-digit'}))+' on '+esc(at.toLocaleDateString('en-IN',{day:'numeric',month:'short'}))+'</p>';
}

/* ---------- rail ---------- */
function renderRail(){
  var rail=$('#rail');if(!rail)return;
  var ss=getSessions(),d=state.date,out=[];
  out.push('<button class="ri'+(state.sid==='overview'?' on':'')+'" data-go="overview"><span class="dot"></span><span class="n">Day overview</span><span class="t"></span></button>');
  var seen={};
  ss.forEach(function(s){
    if(seen[s.grp])return;seen[s.grp]=1;
    var group=ss.filter(function(x){return x.grp===s.grp;});
    out.push('<div class="gh">'+esc(s.grp)+' &middot; '+fmt12(s.start)+'</div>');
    if(s.level){
      out.push('<div class="lvgrid">'+group.map(function(x){
        var t=timing(getEntry(d,x.id),x);
        return '<button class="lv '+t.state+(state.sid===x.id?' on':'')+'" data-go="'+x.id+'" title="'+esc(x.name)+'"><b>'+x.short+'</b><small>'+(shortMark(t)||'&middot;')+'</small></button>';
      }).join('')+'</div>');
      out.push('<button class="ri'+(state.sid==='levels'?' on':'')+'" data-go="levels"><span class="dot"></span><span class="n">All levels in one table</span><span class="t"></span></button>');
    }else{
      group.forEach(function(x){
        var t=timing(getEntry(d,x.id),x);
        out.push('<button class="ri'+(state.sid===x.id?' on':'')+'" data-go="'+x.id+'"><span class="dot '+t.state+'"></span><span class="n">'+esc(x.name)+'</span><span class="t" title="'+esc(chipText(t))+'">'+(shortMark(t)||fmt12(x.start))+'</span></button>');
      });
    }
  });
  rail.innerHTML=out.join('');
  rail.classList.toggle('open',state.railOpen);
  var tg=$('#railToggle');
  if(tg){var cur=state.sid==='overview'?'Day overview':state.sid==='levels'?'All levels':(ss.find(function(x){return x.id===state.sid;})||{}).name;tg.textContent='Sessions: '+(cur||'Day overview')+(state.railOpen?'  ▲':'  ▼');tg.setAttribute('aria-expanded',state.railOpen);}
}

/* ---------- pane: one session ---------- */
function field(label,id,inner){return '<div class="field"><label for="'+id+'">'+label+'</label>'+inner+'</div>';}
function inp(id,f,val,extra){return '<input type="text" id="'+id+'" data-f="'+f+'" value="'+esc(val)+'" autocomplete="off" '+(extra||'')+'>';}
function numInp(id,f,val){return '<input type="number" inputmode="numeric" min="0" step="1" id="'+id+'" data-f="'+f+'" value="'+esc(val==null?'':val)+'">';}
function chipsHtml(list){
  if(!list.length)return '<span class="note">No names added yet.</span>';
  return list.map(function(n,i){return '<span class="name">'+esc(n)+'<button type="button" data-rm="'+i+'" aria-label="Remove '+esc(n)+'">&times;</button></span>';}).join('');
}
function renderSession(sid){
  var d=state.date,s=getSessions().find(function(x){return x.id===sid;});
  if(!s){state.sid='overview';return renderOverview();}
  var e=getEntry(d,sid),held=e.held!==false;
  var h='<div class="sheet" data-sid="'+sid+'">';
  h+='<div class="sh-head"><div><p class="eyebrow">'+esc(s.grp)+(s.place?' &middot; '+esc(s.place):'')+'</p><h2>'+esc(s.name)+'</h2></div>';
  h+='<div class="sched"><span class="mono">'+fmt12(s.start)+' &ndash; '+fmt12(s.end)+'</span><span>Scheduled</span></div></div>';
  h+='<div class="seg" role="radiogroup" aria-label="Was this session held"><label><input type="radio" name="held" value="1"'+(held?' checked':'')+'>Held</label><label><input type="radio" name="held" value="0"'+(!held?' checked':'')+'>Not held</label></div>';
  if(!held){
    h+='<div class="card"><h3>Reason</h3><div class="field"><label for="f-notes">Why was it not held?</label><textarea id="f-notes" data-f="notes">'+esc(e.notes||'')+'</textarea></div></div>'+attr(e)+'</div>';
    return h;
  }
  h+='<div class="card"><h3>Timing</h3><div class="grid2">';
  h+=field('Actual start','f-actualStart','<div class="timerow"><input type="time" id="f-actualStart" data-f="actualStart" value="'+esc(e.actualStart||'')+'"><button type="button" class="btn" data-now="actualStart">Now</button></div>');
  h+=field('Actual end','f-actualEnd','<div class="timerow"><input type="time" id="f-actualEnd" data-f="actualEnd" value="'+esc(e.actualEnd||'')+'"><button type="button" class="btn" data-now="actualEnd">Now</button></div>');
  h+='</div><div class="result" id="tres">'+timingHtml(e,s)+'</div></div>';
  h+='<div class="card"><h3>Details</h3>';
  if(s.kind==='class'){
    h+='<div class="grid2">'+field(s.role,'f-speaker',inp('f-speaker','speaker',e.speaker,'list="dl-speakers"'))+field(s.topic,'f-topic',inp('f-topic','topic',e.topic))+'</div>';
    if(s.counts==='both'){
      h+='<div class="grid2">'+field('Joined online','f-online',numInp('f-online','online',e.online))+field('Joined in person','f-offline',numInp('f-offline','offline',e.offline))+'</div>';
      h+='<div class="total"><span class="lbl">Total participants</span><b id="tot">'+((+e.online||0)+(+e.offline||0))+'</b></div>';
    }else{
      h+='<div class="grid2">'+field('Participants (in person)','f-offline',numInp('f-offline','offline',e.offline))+'</div>';
    }
  }else if(s.kind==='food'){
    h+=field('Menu (one item per line)','f-menu','<textarea id="f-menu" data-f="menu">'+esc(e.menu||'')+'</textarea>');
    h+='<div class="grid2">'+field('Sponsored by','f-sponsor',inp('f-sponsor','sponsor',e.sponsor))+field('People who took prasadam','f-served',numInp('f-served','served',e.served))+'</div>';
    var list=e.servers||[];
    h+='<div class="field"><label for="f-chip">Devotees who served <span id="srvcount">('+list.length+')</span></label>';
    h+='<input type="text" id="f-chip" data-chip="servers" list="dl-servers" autocomplete="off" placeholder="Type a name and press Enter. You can paste a list too.">';
    h+='<div class="chips" id="chips">'+chipsHtml(list)+'</div></div>';
  }else{
    h+='<div class="grid2">'+field('Chaired by','f-facilitator',inp('f-facilitator','facilitator',e.facilitator,'list="dl-speakers"'))+field('Attendees','f-attendees',numInp('f-attendees','attendees',e.attendees))+'</div>';
  }
  h+=field(s.kind==='meeting'?'Agenda and decisions':'Notes','f-notes','<textarea id="f-notes" data-f="notes">'+esc(e.notes||'')+'</textarea>');
  h+='</div>'+attr(e)+'</div>';
  return h;
}

/* ---------- pane: overview ---------- */
function totals(d){
  var ss=sessionsFor(d),on=0,off=0,logged=0,late=0,lateSum=0,lateN=0;
  ss.forEach(function(s){
    var e=getEntry(d,s.id),t=timing(e,s);
    if(t.state!=='pending')logged++;
    if(t.state==='late')late++;
    if(t.state==='late'||t.state==='ok'||t.state==='early'){lateN++;lateSum+=Math.max(t.late,0);}
    if(s.kind==='class'&&e.held!==false){on+=+e.online||0;off+=+e.offline||0;}
  });
  return {total:ss.length,logged:logged,late:late,avgLate:lateN?Math.round(lateSum/lateN):0,on:on,off:off,served:(+getEntry(d,'lunch').served||0)};
}
function who(s,e){
  if(s.kind==='class')return e.speaker||'';
  if(s.kind==='meeting')return e.facilitator||'';
  var n=(e.servers||[]).length;
  return (e.sponsor?'Sponsor: '+e.sponsor:'')+(n?(e.sponsor?' | ':'')+n+' served':'');
}
function renderOverview(){
  var d=state.date,ss=getSessions(),T=totals(d);
  var h='<div class="sheet"><div class="sh-head"><div><p class="eyebrow">'+esc(longDate(d))+'</p><h2>Day overview</h2></div></div>';
  h+='<div class="stats"><div class="stat"><b>'+T.logged+' of '+T.total+'</b><span>Sessions with a start time</span></div>';
  h+='<div class="stat"><b>'+T.late+'</b><span>Late starts (average '+T.avgLate+' min)</span></div>';
  h+='<div class="stat"><b>'+T.on+' / '+T.off+'</b><span>Online / in person in classes</span></div>';
  h+='<div class="stat"><b>'+T.served+'</b><span>Fed at prasadam</span></div></div>';
  var latest=null;ss.forEach(function(s){var x=getEntry(d,s.id);if(x.byName&&x.updatedAt&&(!latest||x.updatedAt>latest.updatedAt))latest=x;});
  h+=attr(latest);
  h+='<div class="tablewrap"><table><thead><tr><th>Time</th><th>Session</th><th>Speaker / sponsor</th><th class="num">Online</th><th class="num">In person</th><th>Started</th><th>Status</th></tr></thead><tbody>';
  ss.forEach(function(s){
    var e=getEntry(d,s.id),t=timing(e,s),cls=s.kind==='class';
    h+='<tr data-go="'+s.id+'"><td class="mono">'+fmt12(s.start)+'</td><td>'+esc(s.name)+'</td><td>'+esc(who(s,e))+'</td>';
    h+='<td class="num">'+(cls&&s.counts==='both'&&e.online!=null?e.online:'')+'</td><td class="num">'+(cls&&e.offline!=null?e.offline:s.kind==='meeting'&&e.attendees!=null?e.attendees:'')+'</td>';
    h+='<td class="mono">'+(e.actualStart?fmt12(e.actualStart):'')+'</td><td>'+chipHtml(t)+'</td></tr>';
  });
  h+='</tbody></table></div>';
  h+='<div class="card"><div class="sub"><h3>Message for the group</h3><button type="button" class="btn primary" data-copy="1">Copy</button></div>';
  h+='<textarea class="report" id="reportText" readonly>'+esc(reportText(d))+'</textarea><div class="note" id="copymsg">Ready to paste into WhatsApp.</div></div></div>';
  return h;
}
function reportText(d){
  var ss=sessionsFor(d),L=[];
  L.push('BACE Sunday Report: '+longDate(d));
  if(isTest(d))L.push('Test and presentation day');
  L.push('');
  ss.forEach(function(s){
    var e=getEntry(d,s.id),t=timing(e,s),parts=[];
    if(t.state==='off'){L.push(fmt12(s.start)+' '+s.name+': not held'+(e.notes?' ('+e.notes+')':''));return;}
    if(t.state==='pending'&&!who(s,e)&&e.online==null&&e.offline==null&&e.served==null)return;
    if(s.kind==='class'){
      if(e.speaker)parts.push((s.role)+': '+e.speaker);
      if(e.topic)parts.push(e.topic);
      if(s.counts==='both')parts.push('Online '+(e.online||0)+', In person '+(e.offline||0));
      else parts.push('Present '+(e.offline||0));
    }else if(s.kind==='food'){
      if(e.menu)parts.push('Menu: '+e.menu.split(/\n+/).filter(Boolean).join(', '));
      if(e.sponsor)parts.push('Sponsored by '+e.sponsor);
      if((e.servers||[]).length)parts.push('Served by '+e.servers.join(', '));
      if(e.served!=null)parts.push('Fed '+e.served);
    }else{
      if(e.facilitator)parts.push('Chaired by '+e.facilitator);
      if(e.attendees!=null)parts.push('Attendees '+e.attendees);
    }
    if(e.actualStart)parts.push('Started '+fmt12(e.actualStart)+' ('+(t.state==='late'?minsText(t.late)+' late':t.state==='early'?minsText(t.late)+' early':'on time')+')');
    L.push(fmt12(s.start)+' '+s.name+': '+parts.join(' | '));
  });
  var T=totals(d);
  L.push('');L.push('Total in classes: Online '+T.on+', In person '+T.off);
  return L.join('\n');
}

/* ---------- pane: all levels ---------- */
function renderLevels(){
  var d=state.date,ss=getSessions().filter(function(s){return s.level;});
  var h='<div class="sheet"><div class="sh-head"><div><p class="eyebrow">Level classes &middot; '+fmt12('10:30')+' &ndash; '+fmt12('12:30')+'</p><h2>All levels</h2></div></div>';
  h+='<div class="tablewrap"><table><thead><tr><th>Level</th><th>Speaker</th><th>Started</th><th>Delay</th><th class="num">Online</th><th class="num">In person</th><th class="num">Total</th></tr></thead><tbody>';
  ss.forEach(function(s){
    var e=getEntry(d,s.id),t=timing(e,s);
    h+='<tr data-sid="'+s.id+'"><td><button type="button" class="btn" data-go="'+s.id+'">'+esc(s.name)+'</button></td>';
    h+='<td><input type="text" data-f="speaker" list="dl-speakers" autocomplete="off" aria-label="Speaker for '+esc(s.name)+'" value="'+esc(e.speaker||'')+'"></td>';
    h+='<td><div class="rowact"><input type="time" class="tm mono" data-f="actualStart" aria-label="Actual start for '+esc(s.name)+'" value="'+esc(e.actualStart||'')+'"><button type="button" class="btn" data-now="actualStart">Now</button></div></td>';
    h+='<td id="lt-'+s.id+'">'+chipHtml(t)+'</td>';
    h+='<td class="num"><input type="number" inputmode="numeric" min="0" data-f="online" aria-label="Online for '+esc(s.name)+'" value="'+esc(e.online==null?'':e.online)+'"></td>';
    h+='<td class="num"><input type="number" inputmode="numeric" min="0" data-f="offline" aria-label="In person for '+esc(s.name)+'" value="'+esc(e.offline==null?'':e.offline)+'"></td>';
    h+='<td class="num" id="tt-'+s.id+'">'+((+e.online||0)+(+e.offline||0))+'</td></tr>';
  });
  h+='</tbody></table></div><p class="note">Open a level on its own to record the topic, end time or a reason it was not held.</p></div>';
  return h;
}

/* ---------- reports ---------- */
function allDates(){return Array.from(new Set(Array.from(entries.values()).map(function(e){return e.date;}).filter(Boolean))).sort().reverse();}
function renderReports(){
  var dates=allDates();
  if(!dates.length)return '<div class="card empty">No Sundays recorded yet. Enter a session on the Sunday tab and it will appear here.</div>';
  var h='<div class="sheet"><div class="sub"><h2>Reports</h2><button type="button" class="btn primary" data-export="1">Export all as CSV</button></div>';
  h+='<div class="sub"><h3>Sundays</h3></div><div class="tablewrap"><table><thead><tr><th>Date</th><th class="num">Late starts</th><th class="num">Avg delay</th><th class="num">Online</th><th class="num">In person</th><th class="num">Fed</th><th>Type</th></tr></thead><tbody>';
  dates.forEach(function(d){
    var T=totals(d);
    h+='<tr data-open="'+d+'"><td>'+esc(shortDate(d))+'</td><td class="num">'+T.late+'</td><td class="num">'+T.avgLate+' min</td><td class="num">'+T.on+'</td><td class="num">'+T.off+'</td><td class="num">'+T.served+'</td><td>'+(isTest(d)?'Test day':'Regular')+'</td></tr>';
  });
  h+='</tbody></table></div>';
  var stats={};
  entries.forEach(function(e){
    if(!e.date||e.sid==='day')return;
    var s=sessionOn(e.date,e.sid);if(!s)return;
    var t=timing(e,s);
    var o=stats[e.sid]||(stats[e.sid]={s:s,held:0,off:0,lateSum:0,lateMax:0,lateN:0,on:0,offl:0});
    if(t.state==='off'){o.off++;return;}
    if(t.state==='pending')return;
    o.held++;o.lateN++;var l=Math.max(t.late,0);o.lateSum+=l;o.lateMax=Math.max(o.lateMax,l);
    o.on+=+e.online||0;o.offl+=+e.offline||0;
  });
  var order=buildSessions(true).map(function(s){return s.id;});
  h+='<div class="sub"><h3>By session</h3></div><div class="tablewrap"><table><thead><tr><th>Session</th><th class="num">Held</th><th class="num">Not held</th><th class="num">Avg delay</th><th class="num">Longest delay</th><th class="num">Avg online</th><th class="num">Avg in person</th></tr></thead><tbody>';
  order.forEach(function(id){
    var o=stats[id];if(!o)return;
    var n=o.held||1;
    h+='<tr><td>'+esc(o.s.name)+'</td><td class="num">'+o.held+'</td><td class="num">'+o.off+'</td><td class="num">'+(o.lateN?Math.round(o.lateSum/o.lateN):0)+' min</td><td class="num">'+o.lateMax+' min</td><td class="num">'+(o.s.counts==='both'?Math.round(o.on/n):'')+'</td><td class="num">'+(o.s.kind==='class'?Math.round(o.offl/n):'')+'</td></tr>';
  });
  h+='</tbody></table></div></div>';
  return h;
}
function csvText(){
  var order=function(id){return buildSessions(true).findIndex(function(s){return s.id===id;});};
  var rows=[['Date','Session','Scheduled start','Actual start','Delay (min)','Scheduled end','Actual end','Over time (min)','Held','Speaker or chair','Topic','Online','In person','Total','Attendees','Menu','Sponsored by','Served by','People fed','Notes','Last updated by']];
  Array.from(entries.values()).filter(function(e){return e.date&&e.sid!=='day';}).sort(function(a,b){return a.date<b.date?-1:a.date>b.date?1:order(a.sid)-order(b.sid);}).forEach(function(e){
    var s=sessionOn(e.date,e.sid);if(!s)return;var t=timing(e,s);
    rows.push([e.date,s.name,s.start,e.actualStart||'',t.late!=null?t.late:'',s.end,e.actualEnd||'',t.over!=null?t.over:'',e.held===false?'No':'Yes',e.speaker||e.facilitator||'',e.topic||'',e.online==null?'':e.online,e.offline==null?'':e.offline,(e.online!=null||e.offline!=null)?(+e.online||0)+(+e.offline||0):'',e.attendees==null?'':e.attendees,(e.menu||'').replace(/\n+/g,'; '),e.sponsor||'',(e.servers||[]).join('; '),e.served==null?'':e.served,(e.notes||'').replace(/\n+/g,' '),e.byName||'']);
  });
  return '﻿'+rows.map(function(r){return r.map(function(c){c=String(c);return /[",\n]/.test(c)?'"'+c.replace(/"/g,'""')+'"':c;}).join(',');}).join('\r\n');
}
function exportCsv(){
  var blob=new Blob([csvText()],{type:'text/csv;charset=utf-8'});
  var a=document.createElement('a');
  a.href=URL.createObjectURL(blob);a.download='bace-sunday-register-'+ymd(new Date())+'.csv';
  document.body.appendChild(a);a.click();a.remove();
  setTimeout(function(){URL.revokeObjectURL(a.href);},1500);
}

/* ---------- account and people ---------- */
var ROLE_LABEL={admin:'Administrator',coordinator:'Coordinator',viewer:'Viewer'};
function renderAccount(){
  var h='<div class="sheet"><div class="sh-head"><div><p class="eyebrow">Signed in as '+esc(me.username)+'</p><h2>Account</h2></div></div>';
  h+='<div class="card"><h3>Change your password</h3><form id="pwform" class="sheet" autocomplete="off"><div class="grid2">';
  h+=field('Current password','pw-cur','<input type="password" id="pw-cur" autocomplete="current-password" required>');
  h+=field('New password (8 or more characters)','pw-new','<input type="password" id="pw-new" autocomplete="new-password" minlength="8" required>');
  h+=field('New password again','pw-new2','<input type="password" id="pw-new2" autocomplete="new-password" minlength="8" required>');
  h+='</div><div class="rowact"><button type="submit" class="btn primary">Update password</button><span class="msg" id="pwmsg" role="status"></span></div></form></div>';
  if(me.role==='admin')h+='<div id="peoplebox" class="sheet"><div class="card empty">Loading people</div></div>';
  return h+'</div>';
}
function setMsg(sel,text,good){var el=$(sel);if(!el)return;el.textContent=text;el.className='msg '+(good?'good':'bad');}
function roleSelect(val,extra){
  return '<select '+(extra||'')+'>'+['viewer','coordinator','admin'].map(function(r){return '<option value="'+r+'"'+(r===val?' selected':'')+'>'+ROLE_LABEL[r]+'</option>';}).join('')+'</select>';
}
function loadPeople(){
  var box=$('#peoplebox');if(!box)return;
  api('GET','/api/users').then(function(list){
    var h='<div class="card"><h3>Add a person</h3><form id="adduser" class="sheet" autocomplete="off"><div class="grid2">';
    h+=field('Full name','au-name','<input type="text" id="au-name" maxlength="80" required>');
    h+=field('Username','au-user','<input type="text" id="au-user" autocapitalize="none" spellcheck="false" maxlength="32" required>');
    h+=field('Password (8 or more characters)','au-pass','<input type="text" id="au-pass" autocomplete="off" minlength="8" required>');
    h+=field('Role','au-role',roleSelect('viewer','id="au-role"'));
    h+='</div><div class="rowact"><button type="submit" class="btn primary">Add person</button><span class="msg" id="aumsg" role="status"></span></div>';
    h+='<p class="note">Viewers can only watch. Coordinators can enter and edit reports. Administrators can also add people and reset passwords. Share the username and password with the person directly. They must choose their own password the first time they sign in.</p></form></div>';
    h+='<div class="sub"><h3>People with access</h3><span class="msg" id="peoplemsg" role="status"></span></div>';
    h+='<div class="tablewrap"><table><thead><tr><th>Name</th><th>Username</th><th>Role</th><th>Access</th><th>Reset password</th></tr></thead><tbody>';
    list.forEach(function(u){
      var self=u.id===me.id;
      h+='<tr data-uid="'+u.id+'"><td>'+esc(u.fullName)+(self?' (you)':'')+'</td><td class="mono">'+esc(u.username)+'</td>';
      h+='<td>'+roleSelect(u.role,'data-role aria-label="Role for '+esc(u.fullName)+'"')+'</td>';
      h+='<td><label class="switch"><input type="checkbox" data-active'+(u.active?' checked':'')+'> '+(u.active?'Active':'Blocked')+'</label></td>';
      h+='<td><div class="pw"><input type="text" placeholder="New password" aria-label="New password for '+esc(u.fullName)+'" autocomplete="off"><button type="button" class="btn" data-setpw>Set</button></div></td></tr>';
    });
    h+='</tbody></table></div>';
    box.innerHTML=h;
  }).catch(function(e){box.innerHTML='<div class="card empty">Could not load people. '+esc(e.message)+'</div>';});
}

/* ---------- render ---------- */
function layout(){
  return '<button type="button" class="railtoggle" id="railToggle" aria-expanded="false"></button><div class="layout"><nav class="rail" id="rail" aria-label="Sessions"></nav><section class="pane" id="pane"></section></div>';
}
function renderPane(){
  var p=$('#pane');if(!p)return;
  p.innerHTML=state.sid==='overview'?renderOverview():state.sid==='levels'?renderLevels():renderSession(state.sid);
  applyReadOnly();
}
function renderAll(){
  var m=$('#main');
  ['day','reports','account'].forEach(function(t){$('#tab-'+t).setAttribute('aria-selected',state.tab===t);});
  renderBar();renderBanner();refreshLists();
  if(state.tab==='reports'){m.innerHTML=renderReports();return;}
  if(state.tab==='account'){m.innerHTML=renderAccount();loadPeople();return;}
  if(!$('#pane'))m.innerHTML=layout();
  renderRail();renderPane();
}
function paneHasFocus(){var a=document.activeElement,p=$('#pane');return p&&a&&a!==document.body&&p.contains(a)&&/INPUT|TEXTAREA/.test(a.tagName);}
function onDataChanged(){
  if(!me)return;
  refreshLists();renderBar();
  if(state.tab==='account')return;
  if(state.tab==='reports'){$('#main').innerHTML=renderReports();return;}
  renderRail();
  if(!paneHasFocus())renderPane();
}
function updateDerived(sid){
  renderRail();
  var s=getSessions().find(function(x){return x.id===sid;});if(!s)return;
  var e=getEntry(state.date,sid);
  var tr=$('#tres');if(tr)tr.innerHTML=timingHtml(e,s);
  var tot=$('#tot');if(tot)tot.textContent=(+e.online||0)+(+e.offline||0);
  var lt=$('#lt-'+sid);if(lt)lt.innerHTML=chipHtml(timing(e,s));
  var tt=$('#tt-'+sid);if(tt)tt.textContent=(+e.online||0)+(+e.offline||0);
  var sc=$('#srvcount');if(sc)sc.textContent='('+(e.servers||[]).length+')';
}

/* ---------- events ---------- */
function go(sid){state.sid=sid;state.railOpen=false;renderRail();renderPane();window.scrollTo({top:0});}
function applyField(el){
  var holder=el.closest('[data-sid]');if(!holder||state.readOnly)return;
  var sid=holder.getAttribute('data-sid'),f=el.getAttribute('data-f'),v=el.value;
  if(el.type==='number')v=v===''?'':Math.max(0,parseInt(v,10)||0);
  var patch={};patch[f]=v;
  setEntry(state.date,sid,patch);
  updateDerived(sid);
}
function addServers(sid,names){
  var e=getEntry(state.date,sid),list=(e.servers||[]).slice();
  names.forEach(function(n){n=n.trim().replace(/\s+/g,' ');if(!n)return;if(!list.some(function(x){return x.toLowerCase()===n.toLowerCase();}))list.push(n);});
  setEntry(state.date,sid,{servers:list});
  var c=$('#chips');if(c)c.innerHTML=chipsHtml(list);
  updateDerived(sid);
}
function patchUser(row,body){
  var id=row.getAttribute('data-uid');
  return api('PATCH','/api/users/'+id,body).then(function(){setMsg('#peoplemsg','Saved.',true);}).catch(function(e){setMsg('#peoplemsg',e.message,false);loadPeople();});
}
document.addEventListener('input',function(ev){
  var el=ev.target;
  if(el.matches&&el.matches('#pane [data-f]'))applyField(el);
});
document.addEventListener('change',function(ev){
  var el=ev.target;
  if(el.name==='held'&&el.closest('#pane')){
    var sid=el.closest('[data-sid]').getAttribute('data-sid');
    setEntry(state.date,sid,{held:el.value==='1'});
    renderPane();renderRail();return;
  }
  if(el.matches&&el.matches('[data-chip]')){
    var sid2=el.closest('[data-sid]').getAttribute('data-sid');
    var parts=el.value.split(/[,\n]+/);el.value='';
    addServers(sid2,parts);return;
  }
  if(el.matches&&el.matches('select[data-role]')){patchUser(el.closest('tr'),{role:el.value});return;}
  if(el.matches&&el.matches('input[data-active]')){patchUser(el.closest('tr'),{active:el.checked}).then(loadPeople);return;}
  if(el.id==='date'){if(el.value){state.date=el.value;state.sid='overview';renderAll();}return;}
  if(el.id==='testDay'){
    setEntry(state.date,'day',{testDay:el.checked});
    if(!el.checked&&state.sid==='common')state.sid='overview';
    renderAll();return;
  }
});
document.addEventListener('keydown',function(ev){
  var el=ev.target;
  if(el.matches&&el.matches('[data-chip]')&&(ev.key==='Enter'||ev.key===',')){
    ev.preventDefault();
    var sid=el.closest('[data-sid]').getAttribute('data-sid');
    var v=el.value;el.value='';addServers(sid,v.split(/[,\n]+/));
  }
});
document.addEventListener('paste',function(ev){
  var el=ev.target;
  if(el.matches&&el.matches('[data-chip]')){
    var t=(ev.clipboardData||window.clipboardData).getData('text');
    if(/[,\n]/.test(t)){ev.preventDefault();addServers(el.closest('[data-sid]').getAttribute('data-sid'),t.split(/[,\n]+/));}
  }
});
function nowHM(){var n=new Date();return pad(n.getHours())+':'+pad(n.getMinutes());}
document.addEventListener('click',function(ev){
  var b=ev.target.closest('button,[data-go],[data-open]');
  if(!b)return;
  if(b.id==='logout'){api('POST','/api/logout',{}).catch(function(){}).then(function(){showLogin();});return;}
  if(b.id==='prev'){state.date=addDays(state.date,-7);state.sid='overview';renderAll();return;}
  if(b.id==='next'){state.date=addDays(state.date,7);state.sid='overview';renderAll();return;}
  if(b.id==='railToggle'){state.railOpen=!state.railOpen;renderRail();return;}
  if(b.hasAttribute('data-tab')){state.tab=b.getAttribute('data-tab');renderAll();return;}
  if(b.hasAttribute('data-now')){
    var inputEl=b.parentNode.querySelector('input[type=time]');
    if(inputEl&&!state.readOnly){inputEl.value=nowHM();applyField(inputEl);}
    return;
  }
  if(b.hasAttribute('data-rm')){
    if(state.readOnly)return;
    var sid=b.closest('[data-sid]').getAttribute('data-sid');
    var list=(getEntry(state.date,sid).servers||[]).slice();list.splice(+b.getAttribute('data-rm'),1);
    setEntry(state.date,sid,{servers:list});
    $('#chips').innerHTML=chipsHtml(list);updateDerived(sid);return;
  }
  if(b.hasAttribute('data-copy')){
    var ta=$('#reportText'),msg=$('#copymsg');
    var fallback=function(){ta.focus();ta.select();msg.textContent='Select all and copy this text.';};
    try{navigator.clipboard.writeText(ta.value).then(function(){msg.textContent='Copied.';},fallback);}catch(e){fallback();}
    return;
  }
  if(b.hasAttribute('data-export')){exportCsv();return;}
  if(b.hasAttribute('data-setpw')){
    var row=b.closest('tr'),inp2=row.querySelector('input[type=text]');
    if(inp2.value.length<8){setMsg('#peoplemsg','The password needs at least 8 characters',false);return;}
    patchUser(row,{password:inp2.value}).then(function(){inp2.value='';});return;
  }
  var open=b.getAttribute('data-open');
  if(open){state.date=open;state.sid='overview';state.tab='day';renderAll();window.scrollTo({top:0});return;}
  var g=b.getAttribute('data-go');
  if(g){state.tab='day';if($('#pane'))go(g);else{state.sid=g;renderAll();}return;}
});
document.addEventListener('submit',function(ev){
  var f=ev.target;ev.preventDefault();
  if(f.id==='loginform'){
    var btn=$('#loginbtn');$('#loginerr').textContent='';btn.disabled=true;
    api('POST','/api/login',{username:$('#lu').value,password:$('#lp').value}).then(function(u){
      me=u;$('#lp').value='';
      if(me.mustChange){$('#fp-cur').value='';showForce();}else start();
    }).catch(function(e){$('#loginerr').textContent=e.message||'Could not sign in';}).then(function(){btn.disabled=false;});
    return;
  }
  if(f.id==='forceform'){
    var n1=$('#fp-new').value,n2=$('#fp-new2').value,fb=$('#forcebtn');
    $('#forceerr').textContent='';
    if(n1!==n2){$('#forceerr').textContent='The two new passwords do not match';return;}
    fb.disabled=true;
    api('POST','/api/me/password',{current:$('#fp-cur').value,next:n1}).then(function(){
      f.reset();me.mustChange=false;start();
    }).catch(function(e){$('#forceerr').textContent=e.message;}).then(function(){fb.disabled=false;});
    return;
  }
  if(f.id==='pwform'){
    var a=$('#pw-new').value,b2=$('#pw-new2').value;
    if(a!==b2){setMsg('#pwmsg','The two new passwords do not match',false);return;}
    api('POST','/api/me/password',{current:$('#pw-cur').value,next:a}).then(function(){
      f.reset();setMsg('#pwmsg','Password updated.',true);
    }).catch(function(e){setMsg('#pwmsg',e.message,false);});
    return;
  }
  if(f.id==='adduser'){
    api('POST','/api/users',{fullName:$('#au-name').value,username:$('#au-user').value,password:$('#au-pass').value,role:$('#au-role').value}).then(function(){
      loadPeople();
      setTimeout(function(){setMsg('#peoplemsg','Person added. Give them their username and password.',true);},300);
    }).catch(function(e){setMsg('#aumsg',e.message,false);});
  }
});

/* ---------- sign in and start ---------- */
function showLogin(){
  me=null;entries.clear();
  if(events){events.close();events=null;}
  clearInterval(pollTimer);
  $('#app').hidden=true;$('#forcepw').hidden=true;$('#login').hidden=false;
  $('#main').innerHTML='';
  var u=$('#lu');if(u)u.focus();
}
function showForce(){
  $('#app').hidden=true;$('#login').hidden=true;$('#forcepw').hidden=false;
  $('#forceerr').textContent='';
  var c=$('#fp-cur');if(c)c.focus();
}
function start(){
  state.readOnly=me.role==='viewer';
  state.tab='day';state.sid='overview';state.date=nextSunday();
  $('#login').hidden=true;$('#forcepw').hidden=true;$('#app').hidden=false;
  $('#whoname').textContent=me.fullName;$('#whorole').textContent=ROLE_LABEL[me.role]||me.role;
  setSync(state.readOnly?'readonly':'saved');
  renderAll();
  fetchAll();connectEvents();
}
api('GET','/api/me').then(function(u){me=u;if(me.mustChange)showForce();else start();}).catch(function(){showLogin();});
})();
